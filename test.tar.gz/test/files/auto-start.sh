#!/bin/bash

date
tag=`cat /home/ubuntu/ts-workspace/tags.env |grep TAG|awk -F'=' '{print $2}'`
if [ "${tag}" == "" ]
then
        echo "tags.env doesn't exist"
        tag=$(docker images|grep -v "REPOSITORY"|head -1|awk -F' ' '{print $2}'|tr -d '\n')
fi
echo ${tag}
source /home/ubuntu/ts-workspace/venv/bin/activate
existing=`docker ps -a|grep -v CONTAINER|wc -l`
if [ "${existing}" != 0 ]
then
        gtxadmin manage down
fi
images=`cat /home/ubuntu/ts-workspace/tags.env |grep IMAGES|awk -F'=' '{print $2}'`
if [ "${images}" == "" ]
then
        echo "tags.env doesn't exist"
        export images=gtx-db,gtx-mongo,gtx-rabbit,gtx-redis,gtx-adminer,gtx-secure-back,gtx-biz,gtx-auto,gtx-auto-model,gtx-ocr,gtx-compliance,gtx-adopter-compliance,gtx-api,gtx-secure,gtx-ris
else
        export images=${images}
fi
echo ${images}
repo=`cat /home/ubuntu/.ts/admin/env/environment.env |grep REPOSITORY|awk -F'=' '{print $2}'`
echo ${repo}
env=`cat /home/ubuntu/.ts/admin/env/environment.env |grep BUILD_ENV|awk -F'=' '{print $2}'`
echo ${env}
gtxadmin manage --repository ${repo} --environment ${env} --tag ${tag} start --images ${images}
deactivate

